//Makes an introduction for the program
void Introduction(int *food_preference, int *no_waste);
void SimpleMealPlanGenerator(int food_preference);
void FoodWasteTerminator3000(int food_preference);
int RandomDays();
void EmptyFridge();
void Startup();